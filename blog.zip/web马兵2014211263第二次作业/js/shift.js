var css=document.getElementById('css');
var shiftButton=document.getElementById('shiftButton');
var banners=document.getElementById('banner_list').getElementsByTagName('a');
var newpics=document.getElementsByTagName('img');

function shift() {
	var value=css.getAttribute('href');
	if (value=="css/style.css") {
		css.setAttribute("href","css/style2.css");
		// 更改banner
		for (var i=0;i<banners.length; i++) {
 			if (banners[i].className=='banner1') banners[i].className='banner4';
 			else if (banners[i].className=='banner2') banners[i].className='banner5';
 			else if (banners[i].className=='banner3') banners[i].className='banner6';
 		}
 		//更改新图片
 		for (var i=0;i<newpics.length; i++) {
 			if (newpics[i].getAttribute('src')=='images/01.jpg') newpics[i].setAttribute('src','images/05.jpg');
 			else if (newpics[i].getAttribute('src')=='images/02.jpg') newpics[i].setAttribute('src','images/06.jpg');
 			else if (newpics[i].getAttribute('src')=='images/03.jpg') newpics[i].setAttribute('src','images/07.jpg');
 			else if (newpics[i].getAttribute('src')=='images/04.jpg') newpics[i].setAttribute('src','images/08.jpg');
 		}
	}
	else {
		css.setAttribute("href","css/style.css");
		// 改回banner
		for (var i=0;i<banners.length; i++) {
 			if (banners[i].className=='banner4') banners[i].className='banner1';
 			else if (banners[i].className=='banner5') banners[i].className='banner2';
 			else if (banners[i].className=='banner6') banners[i].className='banner3';
 		}
 		//改回图片
 		for (var i=0;i<newpics.length; i++) {
 			if (newpics[i].getAttribute('src')=='images/05.jpg') newpics[i].setAttribute('src','images/01.jpg');
 			else if (newpics[i].getAttribute('src')=='images/06.jpg') newpics[i].setAttribute('src','images/02.jpg');
 			else if (newpics[i].getAttribute('src')=='images/07.jpg') newpics[i].setAttribute('src','images/03.jpg');
 			else if (newpics[i].getAttribute('src')=='images/08.jpg') newpics[i].setAttribute('src','images/04.jpg');
 		}
	}
}

shiftButton.onclick=shift;  //当点击button按钮时，执行来回的切换
    